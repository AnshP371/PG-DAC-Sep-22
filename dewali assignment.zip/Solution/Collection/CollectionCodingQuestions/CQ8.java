/*Write a Java program to append the specified element to the end of a linked list.*/

import java.util.*;
class CQ8{
	public static void main(String[] args){
		List<String> colors = new LinkedList<>();
		colors.add("Blue");
		colors.add("Red");
		colors.add("Green");
		colors.add("Yellow");
		colors.add("Orange");
		colors.add("Violet");
		colors.add("Indigo");
		System.out.println(colors);
	}
}	
		