/*Write a Java program to compare two linked lists*/

