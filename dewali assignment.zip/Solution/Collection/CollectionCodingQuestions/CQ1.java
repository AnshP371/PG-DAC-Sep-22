/*Write a Java program to create a new array list, add some colors (string) and print out the
collection*/

import java.util.*;
class CQ1{
	public static void main(String[] args){
		List<String> colors = new ArrayList<>();
		colors.add("Blue");
		colors.add("Red");
		colors.add("Green");
		colors.add("Yellow");
		colors.add("Orange");
		colors.add("Violet");
		colors.add("Indigo");
		System.out.println(colors);
	}
}	
		